from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.



def houda(request):
    return render(request,"hello/hd.html")    

def greet (request,name):
    return render(request,"hello/index.html",{"greetname":name.capitalize()})    
from django.shortcuts import render
import datetime
from django.utils import timezone
# Create your views here.

def index(request):
    now= datetime.datetime.now()
    return render(request,"Halloween/index.html",{"Halloweenday":now.month==10 and now.day==31})
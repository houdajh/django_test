from django.apps import AppConfig


class HalloweenConfig(AppConfig):
    name = 'Halloween'
